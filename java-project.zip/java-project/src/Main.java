import java.util.*;
public class Main
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Full Name:");
        String name = sc.nextLine();
        System.out.println("Enter Sreet Adress:");
        String address =  sc.nextLine();
        System.out.println("Enter City:");
        String city = sc.nextLine();
        System.out.println("Enter Pin Code:");
        int pinCode = sc.nextInt();
        System.out.println("Enter Delivery Preference:");
        boolean deliveryPreference = sc.nextBoolean();
        System.out.println("\nDELIVER DETAILS");
        System.out.println("Name:" + name);
        System.out.println("Address:" + address);
        System.out.println("City:" + city);
        System.out.println("Pin Code:" + pinCode);
        System.out.println("Delivery Preference:" + deliveryPreference);
        sc.close();
    }
}
        
        
      
