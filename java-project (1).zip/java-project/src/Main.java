import java.util.*;
public class Main
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Emp_id:");
        int a = sc.nextInt();
        sc.nextLine();
        System.out.println("Enter Emp Name");
        String m = sc.nextLine();
        System.out.println("Enter Branch of the Emp:");
        String s = sc.nextLine();
        System.out.println("Enter Salary");
        double d = sc.nextDouble();
        System.out.println("Enter Years of Exp:");
        int b = sc.nextInt();
        sc.nextLine();
        System.out.println(a);
        System.out.println(m);
        System.out.println(s);
        System.out.println(d);
        System.out.println(b);
    }
}

        
        
      
