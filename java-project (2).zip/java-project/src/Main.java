import java.util.*;
public class Main
{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Patient Name:");
        String patientName = sc.nextLine();
        System.out.println("Enter Patient ID:");
        int patientId = sc.nextInt();
        System.out.println("Enter Age:");
        int patientAge = sc.nextInt();
        System.out.println("Enter Body Temperature:");
        double temperature = sc.nextDouble();
        System.out.println("Enter Admitted Status:");
        boolean admitted = sc.nextBoolean();
        System.out.println("\nPATTIENT RECORD");
        System.out.println("Patient Name:" + patientName);
        System.out.println("Patient ID:" + patientId);
        System.out.println("Patient Age:" + patientAge);
        System.out.println("Temperature:" + temperature);
        System.out.println("Admitted:" + admitted);
        sc.close();
    }
}

        
      
